-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2021 at 10:12 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orphanage_`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_details`
--

CREATE TABLE `bank_details` (
  `orphanage_id` int(11) NOT NULL,
  `bank_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `branch` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `branch_pincode` int(6) NOT NULL,
  `acc_no` varchar(18) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `re_acc` varchar(18) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `IFSC_code` char(11) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `re_IFSC` char(11) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `UPI_id` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `re_UPI` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `bank_details`
--

INSERT INTO `bank_details` (`orphanage_id`, `bank_name`, `branch`, `branch_pincode`, `acc_no`, `re_acc`, `IFSC_code`, `re_IFSC`, `UPI_id`, `re_UPI`) VALUES
(10001, 'HDF', 'hyd', 903421, '7687686868', '7687686868', 'HDF88888888', 'HDF88888888', '8341415967', '8341415967'),
(10002, 'SBI', 'lingampali', 98764, '1234567891', '1234567891', 'SBI12345678', 'SBI12345678', '8341415969', '8341415969'),
(10003, 'ICICI', 'lingampalli', 123456, '123456789012', '123456789012', 'ICICI111111', 'ICICI111111', '9999999999@paytm', '9999999999@paytm'),
(10004, 'ICICI', 'lingampalli', 123456, '123456789012', '123456789012', 'ICICI22222', 'ICICI22222', '9999999999@paytm', '9999999999@paytm'),
(10005, 'Andhra Bank', 'kukatpally', 123456, '112299331122', '112299331122', 'AB119900112', 'AB119900112', '8902135567', '8902135567'),
(10006, 'Andhra Bank', 'hyderabad', 878888, '74826465483', '74826465483', 'AB112245755', 'AB112245755', '73654786538', '73654786538'),
(10010, 'sbi', 'ongole', 523280, '67675775', '67675775', '89765', '89765', '6543987542', '6543987542'),
(10011, 'sbi', 'ongole', 523280, '456789', '456789', '54243', '54243', '987243536', '987243536'),
(10012, 'hdfc', 'nellore', 523280, '7656654654', '7656654654', '87534567', '87534567', '87654321907', '87654321907'),
(10013, 'hdfc', 'ongole', 523280, '987654321', '987654321', '7654386', '7654386', '76565447', '76565447'),
(10014, 'hdfc', 'ongole', 523280, '765432', '765432', '76424', '76424', '6575656565', '6575656565'),
(10015, 'hdfc', 'ongole', 523280, '765432198', '765432198', '678543', '678543', '8765432190', '8765432190');

-- --------------------------------------------------------

--
-- Table structure for table `verification_details`
--

CREATE TABLE `verification_details` (
  `orphanage_id` int(11) NOT NULL,
  `orphanage_photo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `loc_proof` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `bill` float NOT NULL,
  `manager_image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `adhar_no` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `id_proof` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `govt_certificate` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `verification_details`
--

INSERT INTO `verification_details` (`orphanage_id`, `orphanage_photo`, `loc_proof`, `bill`, `manager_image`, `adhar_no`, `id_proof`, `govt_certificate`) VALUES
(10001, 'icons8-clinic-50.png', 'icons8-flour-of-rye-48.png', 235, 'icons8-baby-48.png', '112233445534', 'icons8-volunteering-64.png', 'newu.png'),
(10002, 'home_app.jpg', '12mb.jpeg', 1234, '20210221_190017_0000.png', '112233445599', 'home_app_f.jpg', 'pexels-photo-1133957.jpeg'),
(10003, '20210221_190017_0000.png', 'pexels-photo-1133957.jpeg', 9099, 'logo.png', '112233445580', 'logo.png', 'logo.png'),
(10004, 'logo.png', 'logo.png', 4444, 'logo.png', '112233445571', 'logo.png', 'logo.png'),
(10005, 'logo.png', 'pexels-photo-1133957.jpeg', 222, 'logo.png', '112233445544', '20210221_190017_0000.png', '20210221_190017_0000.png'),
(10006, '20210221_190017_0000.png', '20210221_190017_0000.png', 1111, 'pexels-photo-1133957.jpeg', '112233445666', 'pexels-photo-1133957.jpeg', 'pexels-photo-1133957.jpeg'),
(10010, 'child6.jpg', 'child 7.jpeg', 856577000, 'clothes.jpg', '76546547', 'child8.jpg', 'books.jpg'),
(10011, 'child1.jpg', 'child2.jpg', 3626, 'child6.jpg', '765453432313', 'child.png', 'child8.jpg'),
(10012, 'child.png', 'child3.jpg', 3626, 'child 7.jpeg', '76546547', 'child2.jpg', 'child8.jpg'),
(10013, 'Screenshot (1).png', 'Screenshot (28).png', 3626770, 'Screenshot (11).png', '765453432313', 'Screenshot (7).png', 'Screenshot (7).png'),
(10014, 'Screenshot (1).png', 'Screenshot (2).png', 56576800, 'Screenshot (4).png', '932456765', 'Screenshot (12).png', 'Screenshot (10).png'),
(10015, 'Screenshot (1).png', 'Screenshot (3).png', 67676900, 'Screenshot (4).png', '6768', 'Screenshot (12).png', 'Screenshot (15).png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_details`
--
ALTER TABLE `bank_details`
  ADD PRIMARY KEY (`orphanage_id`);

--
-- Indexes for table `verification_details`
--
ALTER TABLE `verification_details`
  ADD PRIMARY KEY (`orphanage_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_details`
--
ALTER TABLE `bank_details`
  MODIFY `orphanage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10016;

--
-- AUTO_INCREMENT for table `verification_details`
--
ALTER TABLE `verification_details`
  MODIFY `orphanage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10016;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
