
<?php
include 'o.php';
$n=$_POST["name"];
$c=$_POST["capacity"];
$b=$_POST["boys"];
$g=$_POST["girls"];

$p=$_POST["phn_no1"];
$pn=$_POST["phn_no2"];
$l=$_POST["landline"];
$s=$_POST["staff"];
$e=$_POST["E-mail"];

$fn=$_POST["fname"];
$ln=$_POST["lname"];
$ge=$_POST["gender"];
$m=$_POST["phn_no"];
$mn=$_POST["phn_no_2"];
$em=$_POST["email"];
$bn=$_POST["bank_name"];
$br=$_POST["branch"];
$brc=$_POST["branch_code"];
$acc=$_POST["acc"];
$if=$_POST["IFSC"];
$upi=$_POST["UPI"];

$avg=$_POST["avg"];
$iid=$_POST["Instagram_UserID"];
$iu=$_POST["Instagram_URL"];
$fid=$_POST["Facebook_UserID"];
$fu=$_POST["Facebook_URL"];
$tid=$_POST["Twitter_UserID"];
$tu=$_POST["Twitter_URL"];

$brch1=$_POST["branch1"];
$brch2=$_POST["branch2"];
$brch3=$_POST["branch3"];

/*$d=$_POST["time"];
$di=$_POST["director"];
$pno=$_POST["phno"];
$p=$_POST["profession"];
$c1=$_POST["count1"];
$c2=$_POST["count2"];
$c3=$_POST["count3"];
$c4=$_POST["count4"];
$c=$_POST["no"];
$s=$_POST["staff"];
$mq=$_POST["mreq"];
$mc=$_POST["mrec"];
$a=$_POST["acc"];
$mno=$_POST["mno"];
$dno=$_POST["dno"];
$st=$_POST["street"];
$ci=$_POST["city"];
$sa=$_POST["state"];
$p=$_POST["pincode"];*/
$n2=$_POST["orphnageid"];


$qu1="select *  from `organisation` where `orphanage_id`='$n2'";
$qu2="select *  from `manager_details` where `orphanage_id`='$n2'";
$qu3="select *  from `bank_details` where `orphanage_id`='$n2'";
$qu4="select *  from `other_info` where `orphanage_id`='$n2'";
$qu5="select *  from `other_info_3` where `orphanage_id`='$n2'";
$query1=mysqli_query($conn,$qu1);
$query2=mysqli_query($conn,$qu2);
$query3=mysqli_query($conn,$qu3);
$query4=mysqli_query($conn,$qu4);
$query5=mysqli_query($conn,$qu5);

$row1=mysqli_fetch_object($query1);
$row2=mysqli_fetch_object($query2);
$row3=mysqli_fetch_object($query3);
$row4=mysqli_fetch_object($query4);
$row5=mysqli_fetch_object($query5);

if($row1 and $row2 and $row3 and $row4 and $row5){

  if ($row1){
    $n1=$row1->orphanage_name;
    $c1=$row1->capacity;
    $b1=$row1->boys;
    $g1=$row1->girls;
    
    $p1=$row1->phn_no1;
    $pn1=$row1->phn_no2;
    $l1=$row1->landline;
    $s1=$row1->staff;
    $e1=$row1->email_address;
    
    $qq1="UPDATE `organisation` SET 
    `orphanage_name` = '$n', 
    `capacity`='$c',
    `boys`='$b',
    `girls`='$g',
    `staff`='$s',
    `phn_no1`='$p',
    `phn_no2`='$pn' ,
    `email_address`='$e',
    `landline`='$l'
    WHERE  `organisation`.`orphanage_name` = '$n1'  
    AND `organisation`.`capacity` ='$c1'
    AND `organisation`.`boys`='$b1' 
    AND `organisation`.`girls` ='$g1' 
    AND `organisation`.`staff` ='$s1'  
    AND `organisation`.`phn_no1` ='$p1' 
    AND `organisation`.`phn_no2` ='$pn1' 
    AND `organisation`.`landline` ='$l1' 
    AND `organisation`.`email_address` ='$e1'
    AND`organisation`.`orphanage_id` ='$n2' LIMIT 1";
  
    
    
    
    $q5=mysqli_query($conn,$qq1);
  }
  if ($row2){
    $fn1=$row2->firstname;
        $ln1=$row2->lastname;
        $ge1=$row2->gender;
    $m1=$row2->phn_no;
        $mn1=$row2->phn_no2;
        $em1=$row2->email_id;
  
    $qq2="UPDATE `manager_details` SET
     `firstname`='$fn',
    `lastname`='$ln',
    `gender`='$ge',
    `phn_no`='$m',
    `phn_no2`='$mn',
    `email_id`='$em'
    WHERE 
    `manager_details`.`firstname` ='$fn1'
    AND `manager_details`.`lastname` ='$ln1'
    AND `manager_details`.`gender` ='$ge1'
    AND `manager_details`.`phn_no` ='$m1'
    AND `manager_details`.`phn_no2` ='$mn1'
    AND `manager_details`.`email_id` ='$em1'
    AND`manager_details`.`orphanage_id` ='$n2' LIMIT 1";
  
  $q6=mysqli_query($conn,$qq2);
  }

  if ($row3){
        $bn1=$row3->bank_name;
        $br1=$row3->branch;
        $brc1=$row3->branch_pincode;
        $acc1=$row3->acc_no;
        $if1=$row3->IFSC_code;
        $upi1=$row3->UPI_id;
  
    $qq3="UPDATE `bank_details` SET 
    `bank_name`='$bn',
    `branch`='$br',
    `branch_pincode`='$brc',
    `acc_no`='$acc',
    `re_acc`='$acc',
    `IFSC_code`='$if',
    `re_IFSC`='$if',
    `UPI_id`='$upi',
    `re_UPI`='$upi'
    WHERE 
    `bank_details`.`bank_name` ='$bn1'
    AND `bank_details`.`branch` ='$br1'
    AND `bank_details`.`branch_pincode` ='$brc1'
    AND `bank_details`.`acc_no` ='$acc1'
    AND `bank_details`.`IFSC_code` ='$if1'
    AND`bank_details`.`UPI_id` ='$upi1'
    AND`bank_details`.`orphanage_id` ='$n2' LIMIT 1";
  
  $q7=mysqli_query($conn,$qq3);
  }

  if ($row4){
    $avg1=$row4->avg_turn_over;
        $iid1=$row4->instagram_id;
        $iu1=$row4->instagram_url;
        $fid1=$row4->facebook_id;
        $fu1=$row4->fb_url;
        $tid1=$row4->twitter_id;
        $tu1=$row4->twitter_url;


$qq4="UPDATE `other_info` SET 
`avg_turn_over`='$avg',
`instagram_id`='$iid',
`instagram_url`='$iu',
`facebook_id`='$fid',
`fb_url`='$fu',
`twitter_id`='$tid',
`twitter_url`='$tu'
WHERE 
`other_info`.`avg_turn_over` ='$avg1'
AND `other_info`.`instagram_id` ='$iid1'
AND `other_info`.`instagram_url` ='$iu1'
AND `other_info`.`facebook_id` ='$fid1'
AND `other_info`.`fb_url` ='$fu1'
AND`other_info`.`twitter_id` ='$tid1'
AND`other_info`.`twitter_url` ='$tu1'
AND`other_info`.`orphanage_id` ='$n2' LIMIT 1";

$q8=mysqli_query($conn,$qq4);
}

if ($row5){
  $brch11=$row5->branch1;
        $brch21=$row5->branch2;
        $brch31=$row5->branch3;

  $qq5="UPDATE `other_info_3` SET 
  `branch1`='$brch1',
  `branch2`='$brch2',
  `branch3`='$brch3'
  WHERE 
  `other_info_3`.`branch1` ='$brch11'
  AND `other_info_3`.`branch2` ='$brch21'
  AND `other_info_3`.`branch3` ='$brch31'
  AND`other_info_3`.`orphanage_id` ='$n2' LIMIT 1";

$q9=mysqli_query($conn,$qq5);
}



  if ($q5 and $q6 and $q7 and $q8 and $q9){
   /* echo "Record updated successfully";*/
   
   ?>
   <style>
   .regform{
width: 800px;
background-color: rgba(0,0,0,0.6);
margin: auto;
color: #FFFFFF;
padding: 10px 0px 10px 0px;
text-align: center;
border-radius: 15px 15px 0px 0px;
}
.buttonCls{
       border-radius: 10px;
       width:200px;
       height: 25px;
       background-color:#003366;
       color:white;
       opacity: 0.5;
       font-size:18px;
    }

</style>
    <center><div class="regform"><h1>Thank you<br><br></h1>
	<h2>Your responce has been updated<br></h2></div><center>
	<div align="center">
	<br>
	<a href="orphanage_details2.php"><div class="buttoncls">ORPHANAGE DETAILS</div></a>&emsp;&emsp;<a href="home.html"><div class="buttoncls">HOME</div></a>
	&emsp;&emsp;<a href="orphanmain.php"><div class="buttoncls">MY PROFILE</div></a>
	</div>

   <?php
  }else{
    echo "Error updating record: " . mysqli_error($conn);
  }
  mysqli_close($conn);
}
/*if ($row1){
  $n1=$row->orphanage_name;
  $c1=$row->capacity;
  $b1=$row->boys;
  $g1=$row->girls;
  
  $p1=$row->phn_no1;
  $pn1=$row->phn_no2;
  $l1=$row->landline;
  $s1=$row->staff;
  $e1=$row->email_address;
  $m1=$row->manager_phn_no1;
  $mn1=$row->manager_phn_no2;
  $em1=$row->manager_emailID;
  /*$d1=$row->time;
  $di1=$row->director;
  $pno1=$row->phno;
  $p1=$row->profession;
  $c11=$row->count1;
  $c21=$row->count2;
  $c31=$row->count3;
  $c41=$row->count4;
  $c1=$row->no;
  $s1=$row->staff;
  $mq1=$row->mreq;
  $mc1=$row->mrec;
  $a1=$row->acc;
  $mno1=$row->mno;
  $dno1=$row->dno;
  $st1=$row->street;
  $ci1=$row->city;
  $sa1=$row->state;
  $p1=$row->pincode;
  
  ,`phn_no2`='$p2',`phn_no1`='$p'
  
  ,,`landline`='$l'
  AND `dbms`.`phn_no2` =$p21
  AND `dbms`.`landline` =$l1  AND `dbms`.`phn_no1` =$p1
  
  
  
  $qq1="UPDATE `dbms` SET 
  `orphanage_name` = '$n', 
  `capacity`='$c',
  `boys`='$b',
  `girls`='$g',
  `staff`='$s',
  `phn_no1`='$p',
  `phn_no2`='$pn' ,
  `email_address`='$e',
  `landline`='$l',
  `manager_phn_no1`='$m',
  `manager_phn_no2`='$mn',
  `manager_emailID`='$em'
  WHERE  `dbms`.`orphanage_name` = '$n1'  
  AND `dbms`.`capacity` ='$c1'
  AND `dbms`.`boys`='$b1' 
  AND `dbms`.`girls` ='$g1' 
  AND `dbms`.`staff` ='$s1'  
  AND `dbms`.`phn_no1` ='$p1' 
  AND `dbms`.`phn_no2` ='$pn1' 
  AND `dbms`.`landline` ='$l1' 
  AND `dbms`.`email_address` ='$e1'
  AND`dbms`.`orphanage_id` ='$n2' LIMIT 1";

  
  
  
  $q5=mysqli_query($conn,"UPDATE `dbms` SET 
  `orphanage_name` = '$n', 
  `capacity`='$c',
  `boys`='$b',
  `girls`='$g',
  `staff`='$s',
  `phn_no1`='$p',
  `phn_no2`='$pn' ,
  `email_address`='$e',
  `landline`='$l'
  WHERE  `dbms`.`orphanage_name` = '$n1'  
  AND `dbms`.`capacity` ='$c1'
  AND `dbms`.`boys`='$b1' 
  AND `dbms`.`girls` ='$g1' 
  AND `dbms`.`staff` ='$s1'  
  AND `dbms`.`phn_no1` ='$p1' 
  AND `dbms`.`phn_no2` ='$pn1' 
  AND `dbms`.`landline` ='$l1' 
  AND `dbms`.`email_address` ='$e1'
  AND`dbms`.`orphanage_id` ='$n2' LIMIT 1");

  


  if ($q5){
    echo "Record updated successfully"; 
  }else{
    echo "Error updating record: " . mysqli_error($conn);
  }
  mysqli_close($conn);
}
if ($row2){
  $m1=$row->manager_phn_no1;
  $mn1=$row->manager_phn_no2;
  $em1=$row->manager_emailID;

  $qq2="UPDATE `manager_details` SET 
  `manager_phn_no1`='$m',
  `manager_phn_no2`='$mn',
  `manager_emailID`='$em'
  WHERE 
  AND `manager_details`.`manager_phn_no1` ='$m1'
  AND `manager_details`.`manager_phn_no2` ='$mn1'
  AND `manager_details`.`manager_emailID` ='$em1'
  AND`manager_details`.`orphanage_id` ='$n2' LIMIT 1";

$q6=mysqli_query($conn,"UPDATE `manager_details` SET 
`manager_phn_no1`='$m',
`manager_phn_no2`='$mn',
`manager_emailID`='$em'
WHERE  
AND `manager_details`.`manager_phn_no1` ='$m1'
AND `manager_details`.`manager_phn_no2` ='$mn1'
AND `manager_details`.`manager_emailID` ='$em1'
AND`manager_details`.`orphanage_id` ='$n2' LIMIT 1");
}
   */



