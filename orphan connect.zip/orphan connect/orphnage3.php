<!DOCTYPE html>
<html>
<head>

<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 <title>EnrollmentForm</title>
 <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
<style>


div.af {
    border-radius: 5px;
       padding: 20px;
}
.regform{
        font-family:'Trebuchet MS';
        width: 1000px;
        background-color: rgba(46, 43, 43, 0.8);
        margin: auto;
        color: #FFFFFF;
        padding: 10px 0px 10px 0px;
        text-align: center;
        border-radius: 15px 15px 0px 0px;
        font-size:25px;
}
.regform1{
        font-family:'Trebuchet MS';
        width: 1000px;
        background-color: rgba(46, 43, 43, 0.8);
        margin: auto;
        color: #FFFFFF;
        text-align: center;
        border-radius:0px 0px 0px 0px;
        font-size:20px;
}
.main{
background-color: #555;
opacity: 0.8;
font-family:'Trebuchet MS';
width: 1000px;
margin: auto;
color: #FFFFFF;
}
     td{
        padding: 8px 8px;
        display: table-cell;
        text-align: left;
        vertical-align: top;
        font-family:'Trebuchet MS';
        color:white;
        border-radius: 24px ;
        font-weight:bolder;
     }
    tr{
        font-family:'Trebuchet MS';
        color:white;
        font-weight:bolder;
    }


    body{
    
    background-color:#319c8e;
    background-attachment: fixed;  
    background-size:cover;
    background-position: center;
    }

    /*img{
        width: 125px;
        height: 125px;
        ;
    }*/
    h2{
        font-family:'Trebuchet MS';
        font-size: 40px;
        color:white;
        
    }
    h3{
        font-family:'Trebuchet MS';
        color:white;
        font-size: 30px;
    }

    h4{
        font-family:'Trebuchet MS';
        color:white;
        font-size: 20px;
    }
    .email{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 480px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
    /*.divClass {
    border: 10px solid #fff8ff;/
    /background-color:rgb(236, 219, 188);
    }
    .data{
    /border: 10px solid rgb(236, 219, 188);/
    /background-color: #fff8ff;/
    }*/

    .line{
   height: 4px;
   width: 510px;
   border-radius: 6px;
   position: absolute;
   left: 30%;
   top: 19%;
   background: linear-gradient(to left,rgb(43, 190, 183),rgb(3, 44, 42));
}
.regform h1 span{
 color: #319c8e;
 font-weight: bolder;

}
.regform1 h2 span{
 color:#319c8e ;
 border-radius: 0px;
 font-weight: bolder;

}
.name{
 padding: 4px 20px;
 border-radius: 6px;
}
.date{
    padding: 4px 20px;
    border-radius: 6px;
   }
.number{
    padding: 4px 20px;
    border-radius: 6px;
   }
   .number2{
    padding: 4px;
    border-radius: 6px;
   }
#email{
    padding: 4px;
    border-radius: 6px;
}
.address{
    
    font-family:'Trebuchet MS';
        width: 1000px;
        margin: auto;
        color: #FFFFFF;
        text-align: center;
        border-radius:0px 0px 0px 0px;
        font-size:20px;
}
 .name2{
     padding: 4px;
     border-radius: 6px;
 }  
    .buttonCls{
       border-radius: 10px;
       width: 250px;
       height: 25px;
       background-color:black;
       color:white;
       opacity: 0.7;
       font-size:18px;
    }
    .button{
        font-family:'Trebuchet MS';
       border-radius: 10px;
       width: 150px;
       height: 25px;
       background-color:#319c8e;
       color:white;
       opacity: 0.7;
       text-align:center;
       font-size:18px;
    }
    .b{
        border-radius: 10px;
       width: 400px;
       height: 25px;
       background-color:black;
       color:white;
       opacity: 0.6;
       font-size:18px;
    }
	.buttonCls{
       border-radius: 10px;
       width:200px;
       height: 25px;
       background-color:#003366;
       color:white;
       opacity: 0.5;
       font-size:18px;
    }
</style>
</head>
<body>




<div>
<?php
include 'o.php';
$oid=$_POST["orphnageid"];

$q1=mysqli_query($conn,"select *  from `organisation` where `orphanage_id`='$oid'");
$q2=mysqli_query($conn,"select *  from `manager_details` where `orphanage_id`='$oid'");
$q3=mysqli_query($conn,"select *  from `bank_details` where `orphanage_id`='$oid'"); 
$q4=mysqli_query($conn,"select *  from `other_info` where `orphanage_id`='$oid'");  
$q5=mysqli_query($conn,"select *  from `other_info_3` where `orphanage_id`='$oid'");  
$row1=mysqli_fetch_object($q1);
$row2=mysqli_fetch_object($q2);
$row3=mysqli_fetch_object($q3);
$row4=mysqli_fetch_object($q4);
$row5=mysqli_fetch_object($q5);
if($row1 and $row2 and $row3 and $row4 and $row5)
{
    if($row1){
    $n=$row1->orphanage_name;
    $c=$row1->capacity;
    $b=$row1->boys;
    $g=$row1->girls;
    $s=$row1->staff;
    $e=$row1->email_address;
    $p=$row1->phn_no1;
    $pn=$row1->phn_no2;
    $l=$row1->landline;
    /*


$capacity=$row->capacity;
$boys=$row->boys;
$girls=$row->girls;
$staff=$row->staff;
$phn_no1=$row->phn_no1;
$phn_no2=$row->phn_no2;
$landline=$row->landline;
$email_address=$row->email_address;
$manager_phn_no1=$row->manager_phn_no1;
$manager_phn_no2=$row->manager_phn_no2;
$email_id=$row->email_id;
$bank_name=$row->bank_name;
$branch=$row->branch;
$branch_pincode=$row->branch_pincode;
$acc_no=$row->acc_no;
$IFSC_code=$row->IFSC_code;
$UPI_id=$row->UPI_id;
*/
?>

<form method="post" action="orphanage_4.php" >
<!--ORPHNAGE NAME:<input type="text" name="name" value="" ><br/><br/>
CAPACITY:<input type="number" name="time" value=""><br/><br>
NO OF BOYS:<input type="text" name="director" value="" pattern="[A-Za-z]{1,}"><br/><br/>
NO OF GIRLS:<input type="text" name="phno" value="" pattern="[7-9]{1}[0-9]{9}"><br/><br/>
STAFF :<input type="text" name="profession" value="" pattern="[A-Za-z]{1,}"><br/><br/>
EMAIL ID:<input type="text" name="count1" value=""  pattern="[0-9]{1,}" maxlength="3"><br/><br/>
MANAGER FIRST NAME:<input type="text" name="count2" value=""  pattern="[0-9]{1,}" maxlength="3"><br/><br/>
MANAGER LAST NAME:<input type="text" name="count3" value=""  pattern="[0-9]{1,}" maxlength="3"><br/><br/>
MANAGER CON:<input type="text" name="count4" value=""  pattern="[0-9]{1,}" maxlength="3"><br/><br/>
NO OF CHILDREN:<input type="text" name="no" value=""  pattern="[0-9]{1,}" maxlength="3"><br/><br/>
NO OF STAFF:<input type="text" name="staff" value=""  pattern="[0-9]{1,}" maxlength="3"><br/><br/>
AVERAGE MONEY REQ PER YEAR:<input type="text" name="mreq" value=""  pattern="[0-9]{1,}" maxlength="7"><br/><br/>
AVERAGE FUNDS RECEIVED PER YEAR:<input type="text" name="mrec" value=""  pattern="[0-9]{1,}" maxlength="7"><br/><br/>
BANK ACCOUNT:<input type="text" name="acc" value="" pattern="[0-9]{10}"><br/><br/>
MOBILE NO:<input type="text" name="mno" value="" pattern="[7-9]{1}[0-9]{9}"><br/><br/>
DOOR NO:<input type="text" name="dno" value="" maxlength="10"><br/><br/>
STREET:<input type="text" name="street" value="" pattern="[A-Za-z]{1,}"><br/><br/>
CITY:<input type="text" name="city" value="" pattern="[A-Za-z]{1,}"><br/><br/>
STATE:<input type="text" name="state" value="" pattern="[A-Za-z]{1,}"><br/><br/>
PIN CODE:<input type="text" name="pincode" value="" pattern="[0-9]{6}"><br/><br/>
<input name="orphnageid" value="" type="hidden">
<input type="submit" value="Submit">-->
<section >
    <div class="regform"><h1><span>O</span>RPHANAGE <span>ENROLL</span>MENT</h1></div>

    <div class="main">
    
    <div class="regform1"><h2><span>Ab</span>out <span>Org</span>anisation</h2></div>
            <div class="divClass">
            <table>
            
                <tr>
                   <td> Name of the Orphanage </td>
                   <td><input type="text"  name="name" value="<?=$n?>" required></td>
                </tr>
                
                <tr>
                    <td>Capacity of the Orphanage</td>
                    <td><input type="number" name="capacity" value="<?=$c?>" required></td>
                </tr>
                <tr>
                    <td>Number of Boys</td>
                    <td><input type="number" name="boys" value="<?=$b?>" required></td>
                </tr>
                <tr>
                    <td>Number of Girls</td>
                    <td><input type="number" name="girls" value="<?=$g?>" required></td>
                </tr>
               <tr>
                    <td>Number of Staff</td>
                    <td><input type="number" name="staff" value="<?=$s?>" required></td>
                </tr>
                <tr>
                    <td>Contact Number</td>
                    <td><input type="tel" name="phn_no1" value="<?=$p?>" required></td>
                    <td><input type="tel" name="phn_no2" value="<?=$pn?>"></td> 
                </tr>
                 <tr>
                    <td>Landline Number</td>
                    <td><input type="text" name="landline" value="<?=$l?>"  ></td> 
                </tr>
                <tr>
                    <td>E-mail ID</td>
                    <td><input type="text" id="email" name="E-mail" value="<?=$e?>" required></td>
                </tr>
                
            </table>
            </div>
            <?php
    }
    $q2=mysqli_query($conn,"select *  from `manager_details` where `orphanage_id`='$oid'");
    $row2=mysqli_fetch_object($q2);
    if($row2){
        $fn=$row2->firstname;
        $ln=$row2->lastname;
        $ge=$row2->gender;
        $m=$row2->phn_no;
        $mn=$row2->phn_no2;
        $em=$row2->email_id;
            ?>
            <div class="data">
                <table>
                
                <div class="regform1"><h2><span>Man</span>ager <span>D</span>etails</h2></div>
                <tr>
                    <td>First Name</td>
                    <td><input type ="text"  name="fname" value="<?=$fn?>" required></td>
                    <td>Last Name</td>
                    <td><input type ="text"  name="lname" value="<?=$ln?>" ></td>
                </tr>
                <tr>
                <td>Gender</td>
                <td> <select required name="gender" value="<?=$ge?>">
                <option value="" disabled selected hidden>--choose Gender--</option>
                <option>Male</option>
                <option>Female</option>
                <option>other</option>
                </select></td></tr>
                <tr>
                    <td>Phone Number</td>
                    <td><input type="tel"  name="phn_no" value="<?=$m?>" required></td>
                    <td><input type="tel"  name="phn_no_2" value="<?=$mn?>"></td>
                </tr>
                
                <tr>
                    <td>Email</td>
                    <td><input type="email" id="email" name="email" value="<?=$em?>" required></td>
                </tr>
            </table>

            </div>
            <?php
    }
    $q3=mysqli_query($conn,"select *  from `bank_details` where `orphanage_id`='$oid'");   
    $row3=mysqli_fetch_object($q3);
    if($row3){

        $bn=$row3->bank_name;
        $br=$row3->branch;
        $brc=$row3->branch_pincode;
        $acc=$row3->acc_no;
        $if=$row3->IFSC_code;
        $upi=$row3->UPI_id;
            ?>

            
           
            <div class="divClass">
                <table>
                <div class="regform1"><h2><span>B</span>ank <span>D</span>etails</h2></div>
                    <tr>
                        <td>Bank Name</td>
                        <td><input type="text" name="bank_name" value="<?=$bn?>" required></td>
                    </tr>
                    <tr>
                        <td>Branch</td>
                        <td><input type="text" name="branch" value="<?=$br?>" required></td>
                    </tr>
                    <tr>
                        <td>Branch PINCODE</td>
                        <td><input type="int" name="branch_code" value="<?=$brc?>" required></td>
                    </tr>
                    <tr>
                        <td>Account Number</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" value="<?=$acc?>" name="acc" required></td>
                    </tr>
                    <tr>
                        <td>IFSC Code</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" value="<?=$if?>"  name="IFSC" required></td>
                    </tr>
                
                    <tr>
                        <td>Phone Number/ UPI ID</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" value="<?=$upi?>" name="UPI" required></td>
                    </tr>
                    
                    
                    
                </table>
            </div>
            <?php
    }
    $q4=mysqli_query($conn,"select *  from `other_info` where `orphanage_id`='$oid'");  
    $q5=mysqli_query($conn,"select *  from `other_info_3` where `orphanage_id`='$oid'");  
    $row4=mysqli_fetch_object($q4);
    $row5=mysqli_fetch_object($q5);

    if($row4 and $row5){

        $avg=$row4->avg_turn_over;
        $iid=$row4->instagram_id;
        $iu=$row4->instagram_url;
        $fid=$row4->facebook_id;
        $fu=$row4->fb_url;
        $tid=$row4->twitter_id;
        $tu=$row4->twitter_url;

        $brch1=$row5->branch1;
        $brch2=$row5->branch2;
        $brch3=$row5->branch3;

            ?>


             

          <div class="divClass">
                <table>
                <div class="regform1"><h2><span>Othe</span>r <span>Info</span>rmation</h2></div>
                    <tr>
                        <td>Average Turn Over of the Orphanage</td>
                        <td><input type="int" name="avg" value="<?=$avg?>"  required></td>
                    </tr>
                    <tr>
                        <td>Any other Branches</td>
                        <td><input type="text" name="branch1" value="<?=$brch1?>" ></td>
                        <td><input type="text" name="branch2" value="<?=$brch2?>" ></td>
                        <td><input type="text" name="branch3" value="<?=$brch3?>" ></td>
                    </tr>
                    <tr>
                        <td>Instagram UserID</td>
                        <td><input type="text" name="Instagram_UserID" value="<?=$iid?>" ></td>
                        <td colspan="2"><input type="url" name="Instagram_URL" placeholder="Enter Instagram ID URL " value="<?=$iu?>" class="b"></td>
                    </tr>
                    <tr>
                        <td>Facebook UserID</td>
                        <td><input type="text" name="Facebook_UserID" value="<?=$fid?>"></td>
                        <td colspan="2"><input type="url" name="Facebook_URL" placeholder="Enter Facebook ID URL" value="<?=$fu?>" class="b"></td>
                    </tr>
                    <tr>
                        <td>Twitter UserID</td>
                        <td><input type="text" name="Twitter_UserID" value="<?=$tid?>"></td>
                        <td colspan="2"><input type="url" name="Twitter_URL" placeholder="Enter Twitter ID URL" value="<?=$tu?>"  class="b"></td>
                    </tr>
                </table>
            </div>
            
            <?php
    }

            ?>
            <div class="data">
                    <table align="center">
                     <tr>
                        <td colspan="2" align="left">
                        <input type="SUBMIT"  value="SUBMIT" name="submit" class="button" ></td>
                        <input name="orphnageid" value="<?=$oid?>" type="hidden">   
                     </tr>
                </table>
            </div>
        
</div>
</section>
</form>
</div>
<?php
}
else
{
    echo" invalid responce ". mysqli_error($conn);
	 ?>
	 <p> please enter the valid responce </p>
	<div >
	<br>
	<a href="orphnage2.php"><div class="buttoncls">BACK</div></a>
	</div>

   <?php
}
?>

</body>
</html>
