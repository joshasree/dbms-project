<!DOCTYPE html>
<html lang = "en">
    <head>
    <meta charset="utf-8">
  <title>orphanage emergency management system</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
  <style>
    /*table, th, td {
       border: 1px solid black;
      border-collapse: collapse;
    }*/
    .regform{
        font-family:'Trebuchet MS';
		font-size:30px;
        width: 1000px;
        background-color: rgba(46, 43, 43, 0.6);
        margin: auto;
        color: #FFFFFF;
        padding: 10px 0px 10px 0px;
        text-align: center;
        border-radius: 15px 15px 0px 0px;
	}
	.regform1{
        font-family:'Trebuchet MS';
        width: 1000px;
        background-color: rgba(46, 43, 43, 0.9);
        margin: auto;
        color: #FFFFFF;
        text-align: center;
        border-radius:0px 0px 0px 0px;
        font-size:20px;
	}
.main{
background-color: #555;
opacity: 0.5;
font-family:'Trebuchet MS';
width: 1000px;
margin: auto;
color: #FFFFFF;
}

     td{
        padding: 9px 9px;
        display: table-cell;
        text-align: left;
        vertical-align: top;
        font-size:20px;
		font-family:'Trebuchet MS';
        color:white;
        border-radius: 24px ;
		border-radius: 24px ;
        font-weight:bolder;
     }
    tr{
        font-family:'Trebuchet MS';
        color:white;
        font-weight:bolder;
    }


    body{
    
    background-image: url("https://images.app.goo.gl/JiL5AWV6q38W3TgP6") ;
    background-attachment: fixed;  
    background-size:cover;
    background-position: center;
	text-align:center;
    }

    /*img{
        width: 125px;
        height: 125px;
        ;
    }*/
	h1{
        font-family:'Trebuchet MS';
        color:white;
        font-size: 50px;
    }
	h2{
        font-family:'Trebuchet MS';
        color:white;
        font-size: 40px;
    }
    h3{
        font-family:'Trebuchet MS';
        color:white;
        font-size: 30px;
    }

    h4{
		font-family:'Trebuchet MS';
        color:white;
        font-size: 25px;
    }
    .email{
position: relative;
left: 200px;
top: -37px;
line-height: 40px;
width: 600px;
border-radius: 6px;
padding: 0 22px;
font-size: 16px;
color: #555;
}
    .divClass {
    /*border: 10px solid #fff8ff;/
    /background-color:rgb(236, 219, 188);/
    }
    .data{
    /border: 10px solid rgb(236, 219, 188);/
    /background-color: #fff8ff;*/
    }
	 .line{
   height: 4px;
   width: 510px;
   border-radius: 6px;
   position: absolute;
   left: 30%;
   top: 19%;
   background: linear-gradient(to left,rgb(43, 190, 183),rgb(3, 44, 42));
}
.regform h1 span{
 color: #319c8e;
 font-weight: bolder;

}
.regform1 h2 span{
 color:#319c8e ;
 border-radius: 0px;
 font-weight: bolder;

}
.name{
 padding: 4px 20px;
 border-radius: 6px;
}
.date{
    padding: 4px 20px;
    border-radius: 6px;
   }
.number{
    padding: 4px 20px;
    border-radius: 6px;
   }
   .number2{
    padding: 4px;
    border-radius: 6px;
   }
#email{
    padding: 4px;
    border-radius: 6px;
}
.address{
    
    font-family:'Trebuchet MS';
        width: 1000px;
        margin: auto;
        color: #FFFFFF;
        text-align: center;
        border-radius:0px 0px 0px 0px;
        font-size:20px;
}
 .name2{
     padding: 4px;
     border-radius: 6px;
 }  
 
    .buttonCls{
       border-radius: 10px;
       width: 260px;
       height: 30px;
       background-color:#319c8e;
       color:white;
       opacity: 0.5;
       font-size:22px;
    }
    </style>
	</head>
	<body>
<div>
<?php
	if(array_key_exists('submit', $_POST)) { 
   SavechildDetails(); 
 }
function SavechildDetails()
{
$conn=mysqli_connect('localhost','root','','medical_emergency');
   if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
    }
   ?>
    <div class="regform"><h1>Thank you<br><br></h1>
	<h2>Your responce has been recorded<br></h2></div>
	<div align="center">
	<br>
	<a href="emrgency_information.php"><div class="buttoncls">EMERGENCY DETAILS</div></a>&emsp;&emsp;<a href="home.html"><div class="buttoncls">HOME</div></a>
	<a href="orphanmain.php"><div class="buttoncls">MY PROFILE</div></a>
	</div>

   <?php
   
   IF($_POST['child_name']!='' and $_POST['name']!='' and $_POST['amount']!='')
      { 
       $Child_name=$_POST['child_name'];
	   $Orphanage_name=$_POST['orphanage'];
	   $Gender=$_POST['gender'];
	   $Date_of_birth=$_POST['date'];
	   $Disease=$_POST['disease'];
	   $Therapeutics=$_POST['therapeutics'];
	   $Amount=$_POST['amount'];
	   $Phone_number=$_POST['phone'];
       $Email_id=$_POST['email'];
       
        mysqli_query($conn,"INSERT INTO child_details
		(
			child_name,
			Orphanage_name,
			Gender,
			Dateofbirth,
			Disease,
			Therapeutics,
			Amount,
			Phone_number,
			Email)
            Values ('$Child_name', '$Orphanage_name', '$Gender', '$Date_of_birth', 
					'$Disease', '$Therapeutics', '$Amount', '$Phone_number', '$Email_id')");
		
		mysqli_query($conn,"INSERT INTO emergency_amount
		(
			amount)
			value ('$Amount')");
					
	   $Hospital_name=$_POST['name'];
       $Phone_number1=$_POST['phone'];
	   $Phone_number2=$_POST['phone'];
	   $Door_no=$_POST['doorno'];
	   $Street=$_POST['street'];
	   $Colony=$_POST['colony'];
	   $Area=$_POST['area'];
	   $City=$_POST['city'];
	   $State=$_POST['state'];
       $PINCODE=$_POST['pincode'];
       
        mysqli_query($conn,"INSERT INTO hospital_details
		(
			Name,
			Phone1,
			Phone2,
			Door_no,
			Street,
			Colony,
			Area,
			City,
			State,
			Pin)
            Values ('$Hospital_name', '$Phone_number1', '$Phone_number2', '$Door_no', '$Street', 
					'$Colony', '$Area', '$City', '$State', '$PINCODE')");


if($_FILES['child']['name']!='' and $_FILES['medical_certificate']['name']!='' and  $_FILES['reports']['name']!='' )		
{
	
$fileExtensionsAllowed = ['jpeg','jpg','png'];

$errors1 = []; // Store errors here
$filename1 = $_FILES['child']['name'];
$filetmpname1 = $_FILES['child']['tmp_name'];
$fileSize1 = $_FILES['child']['size'];
$tmp1= explode('.', $filename1);
$fileExtension1 = end($tmp1);
$folder1 = 'child_photo/';

$errors2 = [];
$filename2 = $_FILES['medical_certificate']['name'];
$filetmpname2 = $_FILES['medical_certificate']['tmp_name'];
$fileSize2 = $_FILES['medical_certificate']['size'];
$tmp2= explode('.', $filename2);
$fileExtension2 = end($tmp2);
$folder2= 'medical_certificate/';

$errors3 = [];
$filename3 = $_FILES['reports']['name'];
$filetmpname3 = $_FILES['reports']['tmp_name'];
$fileSize3 = $_FILES['reports']['size'];
$tmp3= explode('.', $filename3);
$fileExtension3 = end($tmp3);	
$folder3= 'reports/';

if (! in_array($fileExtension1,$fileExtensionsAllowed)) {
$errors1[] = "<br>This file extension of " . basename($filename1) . "  is not allowed for CHILD PHOTO.Please upload a JPEG or PNG or PDF file";
}
if (! in_array($fileExtension2,$fileExtensionsAllowed)) {
$errors2[] = "<br>This file extension of " . basename($filename2) . "  is not allowed for MEDICAL CERTIFICATE.Please upload a JPEG or PNG or PDF file";
}
if (! in_array($fileExtension3,$fileExtensionsAllowed)) {
$errors3[] = "<br>This file extension of " . basename($filename3) . "  is not allowed for Reports.Please upload a JPEG or PNG or PDF file";
}

if ($fileSize1 > 4000000) {
$errors1[] = "<br>". basename($filename1) . " exceeds maximum size (4MB) for CHILD PHOTO";
}

if ($fileSize2 > 4000000) {
$errors2[] = "<br>". basename($filename2) . " exceeds maximum size (4MB) for MEDICAL CERTIFICATE";
}
if ($fileSize3 > 4000000) {
$errors3[] = "<br>". basename($filename3) . " exceeds maximum size (4MB) for REPORTS";
}

if (empty($errors)) {
$didUpload1 = move_uploaded_file($filetmpname1, $folder1.$filename1);
$didUpload2 = move_uploaded_file($filetmpname2, $folder2.$filename2);
$didUpload3 = move_uploaded_file($filetmpname3, $folder3.$filename3);
mysqli_query($conn ,"INSERT INTO verification_info
(`child_img`,
`medical_certificate`,
`reports`)
		values('$filename1','$filename2',$filename3')");


if ($didUpload1) {
  echo "<br>The file " . basename($filename1) . " has been uploaded";
} 
if ($didUpload2) {
  echo "<br>The file " . basename($filename2) . " has been uploaded";
} 
if ($didUpload3) {
  echo "<br>The file " . basename($filename3) . " has been uploaded";
} 
} 

else 
{
foreach ($errors1 as $error1) {
  echo "<br>" . $error1 ;
}
foreach ($errors2 as $error2) {
  echo "<br>" . $error2 ;
}
foreach ($errors3 as $error3) {
  echo "<br>" . $error3 ;
}
}
}
	if ($_POST['account_number'] !== $_POST['re_acc'] or $_POST['ifsc'] !== $_POST['re_ifsc'] ) 
	{
		echo '<script>alert("Account details are not matched")</script>'; 
	}
	else if($_POST['bank_name']!=''){
	$bank_name=$_POST['bank_name'];
	$branch=$_POST['branch'];
	$account_number=$_POST['account_number'];
	$re_acc=$_POST['re_acc'];
	$IFSC=$_POST['ifsc'];
	$re_IFSC=$_POST['re_ifsc'];
	$Phone=$_POST['phone'];
	if ($_POST['account_number']==$_POST['re_acc'] and $_POST['ifsc']==$_POST['re_ifsc']) {
    mysqli_query($conn ,"INSERT INTO bank_info
	(bank_name,
	 branch,
	 account_number,
	 re_account,
	 ifsc_code,
	 re_ifsc,
	 phone) 
	VALUES ('$bank_name', '$branch', '$account_number', '$re_acc','$IFSC','$re_IFSC','$Phone')");

 }
 }
	
	
 echo '<script>alert("Form Submitted Successfully..!!")</script>';
 exit;
 
      }
      else
      {
         echo '<script>alert("Please Enter all your Details")</script>';
      }
  }
?>
</div>
	<b>
        <div class="regform"><h1><span>ME</span>DICAL <span>EME</span>RGENCY <span>F</span>ORM</h1></div>
        <div class="main">
        <form action="" method="POST" enctype="multipart/form-data">  
            <div class="divClass">
            <table>
                 <div class="regform1"><h2><span>C</span>hild <span>De</span>tails</h2></div>
                <tr>
                    <td>child Name</td>
                    <td><input type="text" name="child_name" required"><br></td>
                </tr>
                <tr>
                   <td>Name of the Orphanage</td>
                   <td><input type="text"  name="orphanage" required></td>
                </tr>
                <tr>
                <td>Gender</td>
                <td> <select required name="gender">
					 <option value="" disabled selected hidden>--choose Gender--</option>
				   	 <option>Male</option>
					 <option>Female</option>
					 <option>other</option>
					 </select></td>
				</tr>
                <tr>
                    <td>Date of Birth</td>
                    <td><input type="date" name="date" required></td>
                </tr>
                <tr>
                    <td>Disease</td>
                    <td><input type="text" name="disease" required></td>
                </tr>
                <tr>
					<td>Therapeutics</td>
					<td><input type="text" name="therapeutics" required></td>
               </tr>
               <tr>
                    <td>Amount required for treatment</td>
                    <td><input type="number" name="amount" required></td>
               </tr>
                <tr>
                    <td>Phone Number of manager</td>
                    <td><input type="text" name="phone" required></td>  
					<td><input type="text" name="phone"></td>  
                </tr>
                <tr>
					<td>E-mail ID of manager</td>
					<td><input type="email" id="email" name="email" required></td>
                </tr>
                
	
            </table>
            
                <table>
                    <div class="regform1"><h2><span>Ho</span>spital <span>De</span>tails</h2></div>
                   <tr>
                         <td>Name of the Hospital </td>
                         <td><input type="text"  name="name" required></td>
                  </tr>
                  <tr>
                        <td>Phone Number </td>
                        <td><input type="text" name="phone" required></td>
                        <td><input type="text" name="phone"></td>  
                    </tr>
                </table>
                <table>
                  <h3>Hospital Address </h3>
                   <tr for="adress">
                        <td >Door number</td>
                        <td><input type="text" name="doorno" required></td>
                        <td >Street Name</td>
                        <td><input type="text" name="street" ></td>
				    </tr>
                    <tr for="adress">
                        <td >Colony</td>
                        <td><input type="text" name="colony" ></td>
                        <td >Area</td>
                        <td><input type="text" name="area" ></td>
			        </tr>
                    <tr for="adress">
                        <td >City</td>
                        <td><input type="text" name="city" required></td>
                        <td >State</td>
                        <td><input type="text" name="state" required></td>
                        <td >Pin Code</td>
                        <td><input type="text" name="pincode" required></td>
                    </tr>
                </table>
        
                <table>
                    <div class="regform1"><h2><span>Verif</span>ication <span>De</span>tails</h2></div>
					<tr>
						<td>Child photo</td>
						<td ><input type ="file" value="upload" name="child" class="buttonCls" required></td>
					</tr>
                    <tr>
                        <td>Medical certificate</td>
                        <td ><input type ="file" value="upload" name="medical_certificate" class="buttonCls" required></td>
                    </tr>
                   <tr>
                        <td>Reports</td>
                        <td ><input type ="file" value="upload" name="reports" class="buttonCls" required></td>
                    </tr>
                </table>

                 <table>
                    <div class="regform1"><h2><span>Acc</span>ount <span>De</span>tails</h2></div>
					
				    <tr>
                        <td>Bank Name</td>
                        <td><input type="text" name="bank_name" required></td>
                    </tr>
                    <tr>
                        <td>Branch</td>
                        <td><input type="text" name="branch" required></td>
                    </tr>
                    <tr>
                       <td>Bank Account Number</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="account_number" required></td> 
                    </tr>  
					<tr>
                        <td>Reenter Account Number</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="re_acc" required></td>
                    </tr>
                    <tr>
                        <td>IFSC Code</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="ifsc" required></td> 
                    </tr>
					<tr>
                        <td>Reenter IFSC Code</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="re_ifsc" required></td>
                    </tr>
                    <tr>
                        <td>Phone Number</td>
                        <td><input onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" onDrag="return false" onDrop="return false" autocomplete=off type="text" name="phone" required></td> 
                    </tr>
                </table>
				<br>
				<br>
                <div class="data">
                <table align="center">
                    <tr>
                        <td colspan="2" align="center">
                        <input type="submit"  value="SAVE & SUBMIT" name="submit" class="buttonCls" ></td>                        
                    </tr>
                </table>
				</div>
		</form>
    </div>
	</b>
	<br>
	<br>
    </body>
</html>